package com.example.meaningtranslate

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class PracticeActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_TEXT = "text"
        const val PASS_SCORE = 80
        fun intent(ctx: Context, text: String) =
            Intent(ctx, PracticeActivity::class.java).putExtra(EXTRA_TEXT, text)
    }

    private enum class Phase { IDLE, SPEAKING, LISTENING, PASSED, FAILED, ERROR }

    private lateinit var prefs: AppPrefs
    private lateinit var tts: TtsManager
    private var recognizer: SpeechRecognizer? = null
    private var target = ""

    private var phase by mutableStateOf(Phase.IDLE)
    private var score by mutableIntStateOf(0)
    private var hint by mutableStateOf("")
    private var heard by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = AppPrefs(this)
        tts = TtsManager(this, prefs)
        target = intent.getStringExtra(EXTRA_TEXT).orEmpty().trim()
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme()) { Screen() }
            }
        }
    }

    /** الخطوات: 1) ينطق  2) يفتح المايك  3) تقييم  4) لو <80 يحاول تاني */
    private fun startRound() {
        if (target.isBlank()) return
        phase = Phase.SPEAKING
        tts.speak(target) { listen() }
    }

    private fun listen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            fail("محتاجين إذن المايك — فعّله من إعدادات التطبيق"); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            fail("خدمة التعرف على الصوت مش متاحة على الجهاز ده"); return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { phase = Phase.LISTENING }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(code: Int) {
                fail(if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                    "ما سمعتش حاجة — اضغط حاول تاني وانطق بصوت أوضح" else "حصل خطأ في المايك (كود $code)")
            }
            override fun onResults(b: Bundle?) {
                val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (list.isEmpty()) { fail("ما سمعتش حاجة"); return }
                val best = list.map { PronunciationScorer.score(target, it) }.maxBy { it.score }
                score = best.score; hint = best.hint; heard = best.heard
                if (best.score >= PASS_SCORE) {
                    phase = Phase.PASSED
                    lifecycleScope.launch { AppDatabase.get(this@PracticeActivity).masteredDao().recordMastered(target, best.score) }
                } else phase = Phase.FAILED
            }
        })
        val tag = when {
            isArabic(target) -> "ar-EG"
            prefs.accent == "UK" -> "en-GB"
            else -> "en-US"
        }
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        })
    }

    private fun fail(msg: String) { hint = msg; phase = Phase.ERROR }

    @Composable
    private fun Screen() {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
        ) {
            Text("تدريب النطق", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(target, fontSize = 28.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            when (phase) {
                Phase.IDLE -> Button({ startRound() }) { Text("🎓 ابدأ التدريب") }
                Phase.SPEAKING -> Text("🔊 اسمع الأول…")
                Phase.LISTENING -> Text("🎤 دلوقتي انطق…", fontSize = 20.sp)
                Phase.PASSED -> {
                    Text("برافو! 🎉  $score/100", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("اتسجّلت في «إنجازاتي»")
                    Button({ startRound() }) { Text("🔁 كرر تاني") }
                }
                Phase.FAILED -> {
                    Text("حاول تاني — $score/100", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("سمعتك بتقول: $heard")
                    if (hint.isNotBlank()) Text("تلميح: $hint", textAlign = TextAlign.Center)
                    Button({ startRound() }) { Text("🔁 حاول تاني") }
                }
                Phase.ERROR -> {
                    Text(hint, textAlign = TextAlign.Center)
                    Button({ startRound() }) { Text("🔁 حاول تاني") }
                }
            }
            if (phase != Phase.SPEAKING && phase != Phase.LISTENING)
                TextButton({ finish() }) { Text("إغلاق") }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
