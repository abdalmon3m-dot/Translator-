package com.example.meaningtranslate

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class TranslationResult(
    val original: String,
    val translation: String,
    val explanation: String,
    val phonetic: String,
    val sourceLang: String
)

fun isArabic(s: String) = s.any { it in '\u0600'..'\u06FF' }

private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { c.resume(it) }
    addOnFailureListener { c.resumeWithException(it) }
}

private suspend fun Task<*>.awaitDone() = suspendCancellableCoroutine<Unit> { c ->
    addOnSuccessListener { c.resume(Unit) }
    addOnFailureListener { c.resumeWithException(it) }
}

/** ترجمة على الجهاز (ML Kit Translate) من غير API. بتحمّل قاموس اللغة مرة واحدة (حوالي 30 ميجا) وبعدها أوفلاين. */
object OfflineTranslator {
    private val cache = HashMap<String, Translator>()

    private fun client(src: String, tgt: String): Translator = synchronized(cache) {
        cache.getOrPut("$src>$tgt") {
            Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build()
            )
        }
    }

    suspend fun translate(text: String, src: String, tgt: String): String {
        val t = client(src, tgt)
        try {
            t.downloadModelIfNeeded(DownloadConditions.Builder().build()).awaitDone()
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            throw IOException("محتاج نت مرة واحدة بس عشان أحمّل قاموس الترجمة (حوالي 30 ميجا). بعدها بيشتغل من غير نت.")
        }
        return t.translate(text).awaitResult()
    }
}

/** ترجمة جوجل أونلاين (نفس جودة تطبيق Google Translate). من غير مفتاح. لو وقفت بنرجع للترجمة اللي على الجهاز. */
object GoogleWebTranslator {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun chunks(text: String, max: Int = 1800): List<String> {
        if (text.length <= max) return listOf(text)
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (sentence in text.split(Regex("(?<=[.!?؟])\\s+"))) {
            if (cur.isNotEmpty() && cur.length + sentence.length + 1 > max) {
                out.add(cur.toString()); cur = StringBuilder()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(sentence)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    suspend fun translate(text: String, src: String, tgt: String): String = withContext(Dispatchers.IO) {
        chunks(text).joinToString(" ") { one(it, src, tgt) }
    }

    private fun one(q: String, src: String, tgt: String): String {
        val body = FormBody.Builder().add("q", q).build()
        val req = Request.Builder()
            .url("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$src&tl=$tgt&dt=t&ie=UTF-8&oe=UTF-8")
            .post(body)
            .build()
        http.newCall(req).execute().use { resp ->
            val txt = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val arr = JSONArray(txt).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                if (arr.isNull(i)) continue
                val seg = arr.getJSONArray(i)
                if (!seg.isNull(0)) sb.append(seg.getString(0))
            }
            val res = sb.toString().trim()
            if (res.isEmpty()) throw IOException("empty")
            return res
        }
    }
}

/** OCR أوفلاين: يجرب الإنجليزي (ML Kit Latin) ثم العربي (ML Kit Arabic) ويرجع أنضف نص. */
object OcrHelper {
    private val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private suspend fun once(recognizer: com.google.mlkit.vision.text.TextRecognizer, bmp: Bitmap): String =
        suspendCancellableCoroutine { c ->
            recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { c.resume(it.text) }
                .addOnFailureListener { c.resumeWithException(it) }
        }

    suspend fun read(bmp: Bitmap): String {
        val latinText = runCatching { once(latin, bmp) }.getOrDefault("")
        val latinCount = latinText.count { it in 'A'..'Z' || it in 'a'..'z' }
        if (latinCount >= 3) return latinText
        return ""
    }
}

class GeminiClient(private val prefs: AppPrefs) {
    companion object {
        // بنجرب الموديلات بالترتيب؛ لو الأول مشغول أو مش متاح بننتقل للتاني
        val MODELS = listOf("gemini-3.8-flash", "gemini-flash-latest", "gemini-3.8-flash-lite")
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun prompt(direction: String, explain: Boolean, fromImage: Boolean): String {
        val dir = when (direction) {
            "EN_AR" -> "Source is English, target is Arabic."
            "AR_EN" -> "Source is Arabic, target is English."
            else -> "Detect the source: if English translate to Arabic, if Arabic translate to English."
        }
        val explainRule = if (explain)
            "\"explanation\": 1-2 short sentences in simple Egyptian Arabic explaining why this translation was chosen (idiom, context, nuance)."
        else "\"explanation\": empty string."
        val src = if (fromImage)
            "The input is an image of text. First read the text exactly as written (put it in original_text), then translate it."
        else "The input is the text after TEXT:. Put it in original_text."
        return """
You are a professional Arabic<->English translator and language tutor.
$src
$dir
Translate by MEANING and CONTEXT, never word-for-word. Idioms must become the natural equivalent in the target language
(e.g. "It's raining cats and dogs" -> "المطر نازل غزير"). Arabic output should be natural and easy to understand.
Reply with ONLY a JSON object with these keys:
"source_lang": "en" or "ar",
"original_text": the source text,
"translation": the meaning-based translation,
$explainRule
"phonetic": pronunciation guide of the ORIGINAL text: IPA between slashes; if the original is English also add an approximation in Arabic letters.
""".trimIndent()
    }

    suspend fun translateText(text: String, direction: String, explain: Boolean): TranslationResult {
        val parts = JSONArray().put(JSONObject().put("text", prompt(direction, explain, false) + "\n\nTEXT:\n" + text))
        return call(parts, text)
    }

    suspend fun translateImage(bmp: Bitmap, direction: String, explain: Boolean): TranslationResult {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt(direction, explain, true)))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        return call(parts, "")
    }

    private class GeminiHttpException(val code: Int, message: String) : IOException(message)

    private suspend fun call(parts: JSONArray, fallbackOriginal: String): TranslationResult =
        withContext(Dispatchers.IO) {
            val key = prefs.apiKey
            require(key.isNotBlank()) { "مفتاح Gemini API مش موجود — حطه في الإعدادات" }
            val bodyStr = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                .put("generationConfig", JSONObject().put("temperature", 0.3).put("responseMimeType", "application/json"))
                .toString()
            var lastError: Exception = IOException("فشل الاتصال بـ Gemini")
            for (model in MODELS) {
                for (attempt in 1..3) {
                    try {
                        val req = Request.Builder()
                            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                            .header("x-goog-api-key", key)
                            .post(bodyStr.toRequestBody("application/json".toMediaType()))
                            .build()
                        val result = http.newCall(req).execute().use { resp ->
                            val txt = resp.body?.string().orEmpty()
                            if (!resp.isSuccessful) {
                                val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }
                                    .getOrDefault("HTTP ${resp.code}")
                                throw GeminiHttpException(resp.code, msg)
                            }
                            val raw = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                            val j = JSONObject(raw.replace("```json", "").replace("```", "").trim())
                            TranslationResult(
                                original = j.optString("original_text", fallbackOriginal).ifBlank { fallbackOriginal },
                                translation = j.optString("translation"),
                                explanation = j.optString("explanation"),
                                phonetic = j.optString("phonetic"),
                                sourceLang = j.optString("source_lang", "en")
                            )
                        }
                        return@withContext result
                    } catch (e: GeminiHttpException) {
                        lastError = e
                        val modelGone = e.code == 404 || e.message.orEmpty().contains("no longer available")
                        if (modelGone) break
                        if (e.code in listOf(429, 500, 502, 503, 504)) {
                            if (attempt < 3) delay(1500L * attempt)
                        } else {
                            throw e
                        }
                    } catch (e: IOException) {
                        lastError = e
                        if (attempt < 3) delay(1500L * attempt)
                    }
                }
            }
            throw lastError
        }
}

class Repository(ctx: Context) {
    private val appCtx = ctx.applicationContext
    val prefs = AppPrefs(appCtx)
    private val db = AppDatabase.get(appCtx)
    private val gemini = GeminiClient(prefs)

    /**
     * 1) ML Kit بيقرأ النص الإنجليزي أوفلاين.
     * 2) ترجمة جوجل أونلاين؛ ولو النت وقف ML Kit Translate بيترجم على الجهاز.
     * 3) لو النص عربي (ML Kit مفيهوش OCR عربي) وفيه مفتاح Gemini اختياري → Gemini يقرأ الصورة.
     */
    suspend fun translateRegion(bmp: Bitmap): TranslationResult {
        val dir = prefs.direction
        val ocr = (try { OcrHelper.read(bmp) } catch (e: Exception) { "" })
            .replace("-\n", "").replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        val res = if (dir != "AR_EN" && ocr.isNotBlank()) {
            TranslationResult(
                original = ocr,
                translation = try {
                    GoogleWebTranslator.translate(ocr, "en", "ar")
                } catch (e: Exception) {
                    if (e is kotlinx.coroutines.CancellationException) throw e
                    OfflineTranslator.translate(ocr, TranslateLanguage.ENGLISH, TranslateLanguage.ARABIC)
                },
                explanation = "",
                phonetic = "",
                sourceLang = "en"
            )
        } else if (prefs.apiKey.isNotBlank()) {
            gemini.translateImage(bmp, dir, prefs.explain)
        } else {
            throw IOException("مش لاقي نص إنجليزي واضح في المنطقة. قراءة العربي من الشاشة محتاجة مفتاح Gemini (اختياري) في الإعدادات.")
        }
        db.translationDao().insert(
            TranslationEntity(
                original = res.original, translation = res.translation, explanation = res.explanation,
                phonetic = res.phonetic, sourceLang = res.sourceLang
            )
        )
        return res
    }
}
