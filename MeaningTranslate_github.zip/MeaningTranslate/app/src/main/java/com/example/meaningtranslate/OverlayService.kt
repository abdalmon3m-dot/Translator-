package com.example.meaningtranslate

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.meaningtranslate.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var repo: Repository
    private lateinit var tts: TtsManager
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var floatView: View? = null
    private var selectView: View? = null
    private var cardView: View? = null
    private var cardExpanded = false

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var latest: Image? = null
    private val lock = Any()
    private var bgThread: HandlerThread? = null
    private var sw = 0
    private var sh = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        repo = Repository(this)
        tts = TtsManager(this, repo.prefs)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        // لازم startForeground قبل getMediaProjection (شرط من أندرويد 14)
        startAsForeground()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)

        if (projection == null) {
            if (data == null) { stopSelf(); return START_NOT_STICKY }
            setupProjection(code, data)
        }
        if (floatView == null) showFloatingButton()
        running = true
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- foreground
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "النافذة العائمة", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("ترجمة بالمعنى شغّال")
            .setContentText("اضغط إيقاف لإغلاق النافذة العائمة")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIF_ID, n)
    }

    // ---------------------------------------------------------------- screen capture
    private fun setupProjection(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
        }, handler)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels

        bgThread = HandlerThread("capture").also { it.start() }
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) synchronized(lock) { latest?.close(); latest = img }
        }, Handler(bgThread!!.looper))
        reader = r
        display = p.createVirtualDisplay(
            "meaning-capture", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * img.width
        val bmp = Bitmap.createBitmap(img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888)
        plane.buffer.rewind()
        bmp.copyPixelsFromBuffer(plane.buffer)
        return Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    // ---------------------------------------------------------------- UI helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val NF = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

    private fun params(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
    )

    private fun rounded(color: Int, radiusDp: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        textAlignment = View.TEXT_ALIGNMENT_TEXT_START
        setPadding(0, dp(3), 0, dp(3))
    }

    private fun button(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = rounded(0xFF1565C0.toInt(), 20)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(3), dp(6), dp(3), 0)
        }
    }

    // ---------------------------------------------------------------- floating button
    private fun showFloatingButton() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val main = TextView(this).apply {
            text = "ترجم"; textSize = 12f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xE61565C0.toInt(), 0, oval = true)
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 12f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(0xAA555555.toInt(), 0, oval = true)
            setOnClickListener { stopSelf() }
        }
        box.addView(main, LinearLayout.LayoutParams(dp(52), dp(52)))
        box.addView(close, LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(4) })

        val p = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, NF).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(220)
        }
        var startX = 0; var startY = 0; var tx = 0f; var ty = 0f; var moved = false
        main.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = p.x; startY = p.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    if (moved) { p.x = startX + dx; p.y = startY + dy; wm.updateViewLayout(box, p) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) startSelection(); true }
                else -> false
            }
        }
        wm.addView(box, p)
        floatView = box
    }

    // ---------------------------------------------------------------- selection mode
    private fun startSelection() {
        if (selectView != null || projection == null) return
        removeCard()
        floatView?.visibility = View.GONE
        val v = SelectionView(this, { rect -> onSelected(rect) }, { endSelection() })
        val p = params(sw, sh, NF or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, p)
        selectView = v
    }

    private fun endSelection() {
        selectView?.let { runCatching { wm.removeView(it) } }
        selectView = null
        floatView?.visibility = View.VISIBLE
    }

    private fun onSelected(rect: Rect) {
        selectView?.let { runCatching { wm.removeView(it) } }
        selectView = null
        // نستنى شوية عشان طبقة التحديد تختفي ويوصل فريم جديد من الشاشة
        handler.postDelayed({ capture(rect) }, 350)
    }

    private fun capture(rect: Rect) {
        val full = synchronized(lock) { latest?.let { toBitmap(it) } }
        floatView?.visibility = View.VISIBLE
        if (full == null) { renderCard(null, "مقدرتش آخد لقطة للشاشة، جرّب تاني"); return }
        val r = Rect(rect)
        if (!r.intersect(0, 0, full.width, full.height) || r.width() < 8 || r.height() < 8) {
            renderCard(null, "المنطقة صغيرة جدًا"); return
        }
        val crop = Bitmap.createBitmap(full, r.left, r.top, r.width(), r.height())
        renderCard(null, "جاري الترجمة…")
        scope.launch {
            try {
                renderCard(repo.translateRegion(crop), null)
            } catch (e: Exception) {
                renderCard(null, "حصل خطأ: ${e.message}")
            }
        }
    }

    // ---------------------------------------------------------------- result card
    private class MaxHeightScroll(ctx: Context, private val maxPx: Int) : ScrollView(ctx) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxPx, MeasureSpec.AT_MOST))
        }
    }

    private fun removeCard() {
        cardView?.let { runCatching { wm.removeView(it) } }
        cardView = null
    }

    private fun renderCard(res: TranslationResult?, status: String?) {
        removeCard()
        val dark = 0xFF111111.toInt(); val gray = 0xFF666666.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.WHITE, 16)
            elevation = dp(8).toFloat()
        }
        if (res == null) {
            root.addView(label(status ?: "", 16f, dark))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(button("إغلاق") { removeCard() })
            root.addView(row)
        } else {
            root.addView(label(res.translation, 20f, dark, bold = true))
            val extra = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (cardExpanded) View.VISIBLE else View.GONE
            }
            extra.addView(label("النص الأصلي", 12f, gray)); extra.addView(label(res.original, 15f, dark))
            if (res.phonetic.isNotBlank()) { extra.addView(label("النطق", 12f, gray)); extra.addView(label(res.phonetic, 15f, dark)) }
            if (res.explanation.isNotBlank()) { extra.addView(label("ليه الترجمة دي؟", 12f, gray)); extra.addView(label(res.explanation, 15f, dark)) }
            root.addView(MaxHeightScroll(this, (sh * 0.4).toInt()).apply { addView(extra) })

            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(button("🔊 اسمع") { tts.speak(res.original) })
            row.addView(button("🎓 علّمني") {
                startActivity(PracticeActivity.intent(this, res.original).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
            val toggle = button(if (cardExpanded) "⤡ تصغير" else "⤢ تكبير") {}
            toggle.setOnClickListener {
                cardExpanded = !cardExpanded
                extra.visibility = if (cardExpanded) View.VISIBLE else View.GONE
                toggle.text = if (cardExpanded) "⤡ تصغير" else "⤢ تكبير"
            }
            row.addView(toggle)
            row.addView(button("✕") { removeCard() })
            root.addView(row)
        }
        val p = params(sw - dp(24), WindowManager.LayoutParams.WRAP_CONTENT, NF).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(40)
        }
        wm.addView(root, p)
        cardView = root
    }

    // ---------------------------------------------------------------- cleanup
    override fun onDestroy() {
        running = false
        scope.cancel()
        listOf(floatView, selectView, cardView).forEach { v -> v?.let { runCatching { wm.removeView(it) } } }
        display?.release()
        reader?.close()
        synchronized(lock) { latest?.close(); latest = null }
        projection?.stop()
        bgThread?.quitSafely()
        tts.shutdown()
        super.onDestroy()
    }
}

/** طبقة شفافة بتخلي المستخدم يرسم مستطيل بصباعه. */
class SelectionView(
    ctx: Context,
    private val onDone: (Rect) -> Unit,
    private val onCancel: () -> Unit
) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val dim = Paint().apply { color = 0x66000000 }
    private val fill = Paint().apply { color = 0x3300E5FF }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E5FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f * d
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 18f * d; textAlign = Paint.Align.CENTER
    }
    private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f
    private var dragging = false

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        c.drawText("اسحب على الجزء اللي عايز تترجمه", width / 2f, 110f * d, txt)
        if (dragging) {
            val r = RectF(min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))
            c.drawRect(r, fill); c.drawRect(r, border)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; ex = e.x; ey = e.y; dragging = true; invalidate() }
            MotionEvent.ACTION_MOVE -> { ex = e.x; ey = e.y; invalidate() }
            MotionEvent.ACTION_UP -> {
                dragging = false
                val r = Rect(min(sx, ex).toInt(), min(sy, ey).toInt(), max(sx, ex).toInt(), max(sy, ey).toInt())
                if (r.width() > 24 * d && r.height() > 24 * d) onDone(r) else onCancel()
            }
        }
        return true
    }
}
