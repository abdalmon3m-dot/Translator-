package com.example.meaningtranslate

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** كل الإعدادات (ومنها مفتاح الـ API) متخزنة مشفّرة. */
class AppPrefs(context: Context) {
    private val sp = EncryptedSharedPreferences.create(
        context.applicationContext,
        "secure_prefs",
        MasterKey.Builder(context.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    /** "US" أو "UK" */
    var accent: String
        get() = sp.getString("accent", "US") ?: "US"
        set(v) = sp.edit().putString("accent", v).apply()

    var speechRate: Float
        get() = sp.getFloat("rate", 1f)
        set(v) = sp.edit().putFloat("rate", v).apply()

    /** "AUTO" أو "EN_AR" أو "AR_EN" */
    var direction: String
        get() = sp.getString("direction", "AUTO") ?: "AUTO"
        set(v) = sp.edit().putString("direction", v).apply()

    var explain: Boolean
        get() = sp.getBoolean("explain", true)
        set(v) = sp.edit().putBoolean("explain", v).apply()
}
