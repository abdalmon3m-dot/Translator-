package com.example.meaningtranslate

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "translations")
data class TranslationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val original: String,
    val translation: String,
    val explanation: String,
    val phonetic: String,
    val sourceLang: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "mastered", indices = [Index(value = ["text"], unique = true)])
data class MasteredEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val bestScore: Int,
    val masteredAt: Long
)

@Dao
interface TranslationDao {
    @Insert suspend fun insert(e: TranslationEntity): Long

    @Query("SELECT * FROM translations WHERE original LIKE '%' || :q || '%' OR translation LIKE '%' || :q || '%' ORDER BY createdAt DESC")
    fun search(q: String): Flow<List<TranslationEntity>>

    @Query("SELECT COUNT(DISTINCT original) FROM translations")
    fun countDistinct(): Flow<Int>
}

@Dao
interface MasteredDao {
    @Query("SELECT * FROM mastered WHERE text = :t LIMIT 1")
    suspend fun find(t: String): MasteredEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: MasteredEntity)

    @Query("SELECT * FROM mastered ORDER BY masteredAt DESC")
    fun all(): Flow<List<MasteredEntity>>
}

suspend fun MasteredDao.recordMastered(text: String, score: Int) {
    val t = text.trim()
    val old = find(t)
    upsert(MasteredEntity(old?.id ?: 0, t, maxOf(score, old?.bestScore ?: 0), System.currentTimeMillis()))
}

@Database(entities = [TranslationEntity::class, MasteredEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun translationDao(): TranslationDao
    abstract fun masteredDao(): MasteredDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "app.db")
                .build().also { inst = it }
        }
    }
}
