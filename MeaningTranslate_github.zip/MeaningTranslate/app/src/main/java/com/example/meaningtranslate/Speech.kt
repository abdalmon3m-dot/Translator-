package com.example.meaningtranslate

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class TtsManager(ctx: Context, private val prefs: AppPrefs) {
    private lateinit var tts: TextToSpeech
    private var ready = false
    private val pending = ArrayDeque<() -> Unit>()
    private var onDone: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = finish()
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finish()
                })
                while (pending.isNotEmpty()) pending.removeFirst().invoke()
            }
        }
    }

    private fun finish() {
        main.post { val d = onDone; onDone = null; d?.invoke() }
    }

    fun speak(text: String, done: (() -> Unit)? = null) {
        val job = {
            tts.language = when {
                isArabic(text) -> Locale("ar")
                prefs.accent == "UK" -> Locale.UK
                else -> Locale.US
            }
            tts.setSpeechRate(prefs.speechRate)
            onDone = done
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}")
            Unit
        }
        if (ready) job() else pending.add(job)
    }

    fun shutdown() {
        tts.stop(); tts.shutdown()
    }
}

/** تقييم النطق: بنقارن اللي المايك سمعه بالنص الأصلي كلمة كلمة. */
object PronunciationScorer {
    data class Result(val score: Int, val hint: String, val heard: String)

    private fun norm(s: String) = s.lowercase()
        .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private fun sim(a: String, b: String): Double {
        val m = maxOf(a.length, b.length)
        return if (m == 0) 1.0 else 1.0 - lev(a, b).toDouble() / m
    }

    fun score(target: String, heard: String): Result {
        val t = norm(target).split(" ").filter { it.isNotEmpty() }
        val h = norm(heard).split(" ").filter { it.isNotEmpty() }
        if (t.isEmpty()) return Result(0, "", heard)
        if (h.isEmpty()) return Result(0, "ما سمعتش صوت واضح، قرّب من المايك وحاول تاني", heard)

        var total = 0.0
        var worstSim = 1.0
        var worstWord = ""
        var worstHeard = ""
        for (w in t) {
            var best = h[0]; var bestSim = -1.0
            for (x in h) { val s = sim(w, x); if (s > bestSim) { bestSim = s; best = x } }
            total += bestSim
            if (bestSim < worstSim) { worstSim = bestSim; worstWord = w; worstHeard = best }
        }
        val extra = maxOf(0, h.size - t.size)
        val score = ((total / t.size) * 100 - extra * 5).toInt().coerceIn(0, 100)

        var hint = ""
        if (worstWord.isNotEmpty() && worstSim < 0.85) {
            var i = 0
            while (i < worstWord.length && i < worstHeard.length && worstWord[i] == worstHeard[i]) i++
            hint = if (i < worstWord.length)
                "كلمة \"$worstWord\" اتسمعت \"$worstHeard\" — ركّز عند الحرف \"${worstWord[i]}\" (رقم ${i + 1})"
            else "آخر كلمة \"$worstWord\" مش واضح — كمّل نطقها لحد الآخر"
        }
        return Result(score, hint, heard)
    }
}
