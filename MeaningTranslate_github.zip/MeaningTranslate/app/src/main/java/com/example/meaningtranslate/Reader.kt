package com.example.meaningtranslate

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.speech.RecognizerIntent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** بيشيل الصورة اللي اتصوّرت/اتختارت بين الشاشتين. */
object ImageHolder {
    @Volatile var bitmap: Bitmap? = null
}

// ------------------------------------------------------------------ تحميل الصور
private fun sampleFor(w: Int, h: Int): Int {
    var s = 1
    while (maxOf(w, h) / s > 2600) s *= 2
    return s
}

private fun rotated(bmp: Bitmap, deg: Int): Bitmap {
    if (deg == 0) return bmp
    val m = Matrix().apply { postRotate(deg.toFloat()) }
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}

fun loadBitmap(ctx: Context, uri: Uri): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    val opts = BitmapFactory.Options().apply { inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight) }
    val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    val deg = try {
        ctx.contentResolver.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
    } catch (e: Exception) {
        0
    }
    if (bmp == null) null else rotated(bmp, deg)
} catch (e: Exception) {
    null
}

fun loadBitmapFile(file: File): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    val opts = BitmapFactory.Options().apply { inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight) }
    val bmp = BitmapFactory.decodeFile(file.absolutePath, opts)
    val deg = try {
        ExifInterface(file.absolutePath).rotationDegrees
    } catch (e: Exception) {
        0
    }
    if (bmp == null) null else rotated(bmp, deg)
} catch (e: Exception) {
    null
}

// ------------------------------------------------------------------ شاشة الترجمة النصية (زي Google Translate)
@Composable
fun TranslateScreen(prefs: AppPrefs, onOpenImage: () -> Unit) {
    val ctx = LocalContext.current
    val repo = remember { Repository(ctx) }
    val scope = rememberCoroutineScope()
    val tts = remember { TtsManager(ctx, prefs) }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }
    val clipboard = LocalClipboardManager.current

    var text by remember { mutableStateOf("") }
    var src by remember { mutableStateOf("en") }
    var tgt by remember { mutableStateOf("ar") }
    var result by remember { mutableStateOf("") }
    var alts by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }

    fun langName(c: String) = if (c == "ar") "العربية" else "English"

    // لو الكلام عربي نقلب الاتجاه لوحده، والعكس
    LaunchedEffect(text) {
        if (text.isNotBlank()) {
            if (isArabic(text) && src == "en") { src = "ar"; tgt = "en" }
            else if (!isArabic(text) && src == "ar") { src = "en"; tgt = "ar" }
        }
    }

    // ترجمة تلقائية بعد ما تبطّل كتابة
    LaunchedEffect(text, src, tgt) {
        err = ""
        val t = text.trim()
        if (t.isEmpty()) {
            result = ""; alts = ""; busy = false
            return@LaunchedEffect
        }
        delay(600)
        busy = true
        try {
            result = repo.translateText(t, src, tgt)
            alts = if (!t.contains(' ') && t.length <= 40) repo.dictionary(t, src, tgt) else ""
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            result = ""; alts = ""
            err = e.message ?: "حصل خطأ في الترجمة"
        }
        busy = false
    }

    // نحفظ في السجل بس لما النتيجة تثبت
    LaunchedEffect(result) {
        if (result.isNotBlank()) {
            delay(2500)
            repo.saveHistory(text.trim(), result, src)
        }
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !spoken.isNullOrBlank()) text = spoken
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { loadBitmap(ctx, uri) }
            if (bmp != null) { ImageHolder.bitmap = bmp; onOpenImage() } else err = "مقدرتش أفتح الصورة"
        }
    }
    val photoFile = remember {
        val dir = File(ctx.cacheDir, "photos")
        dir.mkdirs()
        File(dir, "page.jpg")
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) scope.launch {
            val bmp = withContext(Dispatchers.IO) { loadBitmapFile(photoFile) }
            if (bmp != null) { ImageHolder.bitmap = bmp; onOpenImage() } else err = "مقدرتش أفتح الصورة"
        }
    }

    fun startMic() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (src == "ar") "ar-EG" else "en-US")
        }
        try { micLauncher.launch(i) } catch (e: Exception) { err = "التعرف على الصوت مش متاح على جهازك" }
    }

    fun startCamera() {
        try {
            if (!photoFile.exists()) photoFile.createNewFile()
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", photoFile)
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            err = "الكاميرا مش متاحة: ${e.message}"
        }
    }

    fun swap() {
        val s = src; src = tgt; tgt = s
        if (result.isNotBlank()) text = result
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("ترجمة", fontSize = 26.sp, fontWeight = FontWeight.Bold)

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(langName(src), Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = { swap() }) { Text("⇄", fontSize = 22.sp) }
            Text(langName(tgt), Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            maxLines = 8,
            textStyle = TextStyle(fontSize = 20.sp, textDirection = TextDirection.Content),
            label = { Text("اكتب أو الصق كلمة أو جملة") },
            trailingIcon = {
                if (text.isNotEmpty()) TextButton(onClick = { text = "" }) { Text("✕") }
            }
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { startMic() }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("🎤 صوت") }
            OutlinedButton(onClick = { startCamera() }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("📷 كاميرا") }
            OutlinedButton(onClick = { galleryLauncher.launch("image/*") }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("🖼️ صورة") }
        }

        if (text.isBlank()) {
            TextButton(onClick = { clipboard.getText()?.text?.let { text = it } }) { Text("📋 لصق من الحافظة") }
        }

        if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)

        if (result.isNotBlank()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        result,
                        style = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold, textDirection = TextDirection.Content)
                    )
                    if (alts.isNotBlank()) {
                        Text("معاني تانية", fontSize = 12.sp)
                        Text(alts, style = TextStyle(fontSize = 16.sp, textDirection = TextDirection.Content))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        TextButton(onClick = { tts.speak(text.trim()) }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("🔊 الأصل") }
                        TextButton(onClick = { tts.speak(result) }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("🔊 الترجمة") }
                        TextButton(onClick = { clipboard.setText(AnnotatedString(result)) }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("📋 نسخ") }
                        if (src == "en") {
                            TextButton(onClick = { ctx.startActivity(PracticeActivity.intent(ctx, text.trim())) }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("🎓 علّمني") }
                        }
                    }
                }
            }
        }

        Text(
            "للترجمة فوق أي تطبيق استخدم تبويب «العائمة». ولكتاب ورقي: صوّره بالكاميرا وظلّل الجزء اللي عايزه.",
            fontSize = 12.sp
        )
    }
}

// ------------------------------------------------------------------ شاشة صورة الكتاب + قلم التحديد
@Composable
fun ImageScreen(prefs: AppPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val repo = remember { Repository(ctx) }
    val scope = rememberCoroutineScope()
    val tts = remember { TtsManager(ctx, prefs) }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }
    val clipboard = LocalClipboardManager.current
    val bmp = remember { ImageHolder.bitmap }

    var hv by remember { mutableStateOf<HighlightView?>(null) }
    var hasSel by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    fun run(block: suspend () -> List<Pair<String, String>>, emptyMsg: String) {
        scope.launch {
            busy = true; msg = ""; items = emptyList()
            try {
                val r = block()
                items = r
                if (r.isEmpty()) msg = emptyMsg
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                msg = e.message ?: "حصل خطأ"
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Text("ظلّل الجزء بإصبعك (قلم التحديد)، وقرّب بإصبعين.", Modifier.weight(1f), fontSize = 12.sp)
        }

        if (bmp == null) {
            Text("مفيش صورة. ارجع واختار صورة أو صوّر صفحة.", Modifier.padding(16.dp))
        } else {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AndroidView(
                    factory = { c ->
                        HighlightView(c).also {
                            it.onSelectionChanged = { has -> hasSel = has }
                            it.bitmap = bmp
                            hv = it
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        val crop = hv?.selection()
                        if (crop == null) {
                            msg = "ظلّل جزء الأول (أو المنطقة صغيرة جدًا)."
                        } else {
                            run({ repo.translateImagePart(crop) }, "ما لقيتش نص إنجليزي واضح في المظلّل. قرّب وظلّل تاني.")
                        }
                    },
                    enabled = hasSel && !busy,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("ترجم المظلّل") }
                OutlinedButton(
                    onClick = { run({ repo.translatePage(bmp) }, "ما لقيتش نص إنجليزي في الصفحة.") },
                    enabled = !busy,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("ترجم الصفحة كلها") }
                TextButton(onClick = { hv?.clear() }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("مسح") }
            }

            if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp))
            if (msg.isNotBlank()) Text(msg, Modifier.padding(horizontal = 12.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.error)

            if (items.isNotEmpty()) {
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 260.dp).verticalScroll(rememberScrollState()).padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items.forEach { (orig, tr) ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(orig, style = TextStyle(fontSize = 14.sp, textDirection = TextDirection.Content))
                                Spacer(Modifier.padding(2.dp))
                                Text(tr, style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold, textDirection = TextDirection.Content))
                                Row {
                                    TextButton(onClick = { tts.speak(orig) }) { Text("🔊 الأصل") }
                                    TextButton(onClick = { clipboard.setText(AnnotatedString(tr)) }) { Text("📋 نسخ") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ View بتعرض الصورة وبتسمح بالتظليل والتقريب
class HighlightView(ctx: Context) : View(ctx) {
    private class Stroke(val path: Path, val width: Float) {
        val bounds = RectF()
        private var empty = true
        fun add(x: Float, y: Float) {
            val e = width / 2f
            if (empty) { bounds.set(x - e, y - e, x + e, y + e); empty = false }
            else bounds.union(x - e, y - e, x + e, y + e)
        }
    }

    private val d = resources.displayMetrics.density
    private val m = Matrix()
    private val inv = Matrix()
    private val strokes = ArrayList<Stroke>()
    private var cur: Stroke? = null
    private var multi = false
    private var lastMx = 0f
    private var lastMy = 0f
    private var fitScale = 1f
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0x66FFEB3B
    }

    var onSelectionChanged: ((Boolean) -> Unit)? = null

    var bitmap: Bitmap? = null
        set(v) {
            field = v
            strokes.clear(); cur = null
            fit()
            notifySel()
            invalidate()
        }

    private val scaleDetector = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(det: ScaleGestureDetector): Boolean {
            val cs = curScale()
            val target = (cs * det.scaleFactor).coerceIn(fitScale * 0.8f, fitScale * 12f)
            val f = target / cs
            m.postScale(f, f, det.focusX, det.focusY)
            invalidate()
            return true
        }
    })

    private fun curScale(): Float {
        val v = FloatArray(9)
        m.getValues(v)
        return v[Matrix.MSCALE_X]
    }

    private fun fit() {
        val b = bitmap ?: return
        if (width == 0 || height == 0) return
        val s = minOf(width / b.width.toFloat(), height / b.height.toFloat())
        fitScale = s
        m.reset()
        m.postScale(s, s)
        m.postTranslate((width - b.width * s) / 2f, (height - b.height * s) / 2f)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fit()
        invalidate()
    }

    private fun notifySel() { onSelectionChanged?.invoke(strokes.isNotEmpty()) }

    fun clear() {
        strokes.clear(); cur = null
        notifySel()
        invalidate()
    }

    /** الجزء المظلّل مقصوص من الصورة الأصلية. */
    fun selection(): Bitmap? {
        val b = bitmap ?: return null
        if (strokes.isEmpty()) return null
        val u = RectF()
        var first = true
        for (s in strokes) {
            if (first) { u.set(s.bounds); first = false } else u.union(s.bounds)
        }
        val r = Rect(u.left.toInt(), u.top.toInt(), u.right.toInt() + 1, u.bottom.toInt() + 1)
        if (!r.intersect(0, 0, b.width, b.height) || r.width() < 8 || r.height() < 8) return null
        return Bitmap.createBitmap(b, r.left, r.top, r.width(), r.height())
    }

    override fun onDraw(c: android.graphics.Canvas) {
        val b = bitmap ?: return
        c.save()
        c.concat(m)
        c.drawBitmap(b, 0f, 0f, bmpPaint)
        for (s in strokes) {
            pen.strokeWidth = s.width
            c.drawPath(s.path, pen)
        }
        c.restore()
    }

    private fun toBmp(x: Float, y: Float): FloatArray {
        m.invert(inv)
        val p = floatArrayOf(x, y)
        inv.mapPoints(p)
        return p
    }

    private fun cancelStroke() {
        cur?.let { strokes.remove(it) }
        cur = null
        notifySel()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (bitmap == null) return false
        parent?.requestDisallowInterceptTouchEvent(true)
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false
                val p = toBmp(e.x, e.y)
                val w = 18f * d / curScale()
                val path = Path()
                path.moveTo(p[0], p[1])
                path.lineTo(p[0] + 0.01f, p[1])
                val s = Stroke(path, w)
                s.add(p[0], p[1])
                strokes.add(s)
                cur = s
                notifySel()
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                multi = true
                cancelStroke()
                if (e.pointerCount >= 2) {
                    lastMx = (e.getX(0) + e.getX(1)) / 2f
                    lastMy = (e.getY(0) + e.getY(1)) / 2f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 2) {
                    val mx = (e.getX(0) + e.getX(1)) / 2f
                    val my = (e.getY(0) + e.getY(1)) / 2f
                    m.postTranslate(mx - lastMx, my - lastMy)
                    lastMx = mx
                    lastMy = my
                } else if (!multi) {
                    val s = cur
                    if (s != null) {
                        val p = toBmp(e.x, e.y)
                        s.path.lineTo(p[0], p[1])
                        s.add(p[0], p[1])
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                cur = null
                multi = false
                invalidate()
            }
        }
        return true
    }
}
