package com.example.meaningtranslate

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import java.util.Locale

@Composable
fun AppRoot(prefs: AppPrefs, running: Boolean, onActivate: () -> Unit, onDeactivate: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = lightColorScheme()) {
            val nav = rememberNavController()
            val tabs = listOf(
                Triple("home", "الرئيسية", "🏠"), Triple("history", "السجل", "🕘"),
                Triple("achv", "إنجازاتي", "🏆"), Triple("settings", "الإعدادات", "⚙️")
            )
            val cur = nav.currentBackStackEntryAsState().value?.destination?.route
            Scaffold(bottomBar = {
                NavigationBar {
                    tabs.forEach { (route, name, icon) ->
                        NavigationBarItem(
                            selected = cur == route,
                            onClick = { nav.navigate(route) { popUpTo("home"); launchSingleTop = true } },
                            icon = { Text(icon) }, label = { Text(name) }
                        )
                    }
                }
            }) { pad ->
                NavHost(nav, "home", Modifier.padding(pad)) {
                    composable("home") { HomeScreen(prefs, running, onActivate, onDeactivate) }
                    composable("history") { HistoryScreen(prefs) }
                    composable("achv") { AchievementsScreen() }
                    composable("settings") { SettingsScreen(prefs) }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(prefs: AppPrefs, running: Boolean, onActivate: () -> Unit, onDeactivate: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("ترجمة بالمعنى", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("مش مجرد مترجم — مساعد بيفهم السياق ويعلّمك تنطق.", fontSize = 16.sp)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
            Text("الترجمة بتشتغل على جهازك من غير مفتاح API. أول مرة بس محتاج نت لتحميل القاموس (حوالي 30 ميجا).", Modifier.padding(14.dp))
        }
        Button(onClick = if (running) onDeactivate else onActivate, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text(if (running) "إيقاف النافذة العائمة" else "تفعيل النافذة العائمة", fontSize = 18.sp)
        }
        Text("إزاي تستخدمه:", fontWeight = FontWeight.Bold)
        Text("1) فعّل النافذة العائمة ووافق على الأذونات.\n" +
            "2) افتح أي تطبيق واضغط زرار «ترجم».\n" +
            "3) اسحب مستطيل على النص، وبعدين حرّك النقط الأربعة في الأركان لتظبيط التحديد (أو اسحب جوّه المستطيل لنقله) واضغط «ترجم».\n" +
            "4) هتظهر الترجمة في كارت — اضغط 🔊 للنطق أو 🎓 للتدريب.\n\n" +
            "ملاحظة: لما أندرويد يسألك على تسجيل الشاشة اختار «الشاشة بالكامل».")
    }
}

@Composable
fun HistoryScreen(prefs: AppPrefs) {
    val ctx = LocalContext.current
    val dao = remember { AppDatabase.get(ctx).translationDao() }
    var q by remember { mutableStateOf("") }
    val list by remember(q) { dao.search(q) }.collectAsState(initial = emptyList())
    val tts = remember { TtsManager(ctx, prefs) }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("ابحث في السجل") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) Text("مفيش ترجمات لسه.", Modifier.padding(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { e ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(e.original, fontSize = 15.sp)
                        Text(e.translation, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        if (e.phonetic.isNotBlank()) Text(e.phonetic, fontSize = 13.sp)
                        Row {
                            TextButton({ tts.speak(e.original) }) { Text("🔊 اسمع") }
                            TextButton({ ctx.startActivity(PracticeActivity.intent(ctx, e.original)) }) { Text("🎓 علّمني") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AchievementsScreen() {
    val ctx = LocalContext.current
    val db = remember { AppDatabase.get(ctx) }
    val mastered by db.masteredDao().all().collectAsState(initial = emptyList())
    val total by db.translationDao().countDistinct().collectAsState(initial = 0)
    val progress = if (total == 0) 0f else (mastered.size / total.toFloat()).coerceAtMost(1f)

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("إنجازاتي", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("أتقنت ${mastered.size} من $total (${(progress * 100).toInt()}٪)")
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        if (mastered.isEmpty()) Text("لسه ما أتقنتش كلمات — جرّب زرار «علّمني».")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(mastered, key = { it.id }) { m ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("✅ ${m.text}", Modifier.weight(1f))
                        Text("${m.bestScore}/100", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(prefs: AppPrefs) {
    var key by remember { mutableStateOf(prefs.apiKey) }
    var accent by remember { mutableStateOf(prefs.accent) }
    var rate by remember { mutableFloatStateOf(prefs.speechRate) }
    var dir by remember { mutableStateOf(prefs.direction) }
    var explain by remember { mutableStateOf(prefs.explain) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("الإعدادات", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            key, { key = it; prefs.apiKey = it }, Modifier.fillMaxWidth(),
            label = { Text("مفتاح Gemini API (اختياري)") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )
        Text("مش مطلوب للإنجليزي ← عربي. بيتستخدم بس لقراءة النص العربي من الشاشة. تجيبه مجانًا من aistudio.google.com/apikey", fontSize = 12.sp)

        Text("لهجة النطق (إنجليزي)", fontWeight = FontWeight.Bold)
        Choice("أمريكي", accent == "US") { accent = "US"; prefs.accent = "US" }
        Choice("بريطاني", accent == "UK") { accent = "UK"; prefs.accent = "UK" }

        Text("سرعة النطق: ${String.format(Locale.US, "%.1f", rate)}x", fontWeight = FontWeight.Bold)
        Slider(rate, { rate = it; prefs.speechRate = it }, valueRange = 0.5f..1.5f)

        Text("اتجاه الترجمة", fontWeight = FontWeight.Bold)
        Choice("تلقائي", dir == "AUTO") { dir = "AUTO"; prefs.direction = "AUTO" }
        Choice("إنجليزي ← عربي", dir == "EN_AR") { dir = "EN_AR"; prefs.direction = "EN_AR" }
        Choice("عربي ← إنجليزي", dir == "AR_EN") { dir = "AR_EN"; prefs.direction = "AR_EN" }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("اشرحلي ليه الترجمة دي", Modifier.weight(1f))
            Switch(explain, { explain = it; prefs.explain = it })
        }
    }
}

@Composable
private fun Choice(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected, onClick)
        Text(text)
    }
}
