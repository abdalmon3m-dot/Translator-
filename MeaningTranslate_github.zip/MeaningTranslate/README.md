# ترجمة بالمعنى — Android (Kotlin)

## التشغيل
1. ثبّت Android Studio (آخر إصدار) وافتح المجلد MeaningTranslate كمشروع. سيبه يعمل Sync ويحمّل Gradle 8.9 والمكتبات.
2. هات مفتاح Gemini مجاني من https://aistudio.google.com/apikey
3. وصّل موبايل أندرويد (8.0+) بوضع USB debugging، أو استخدم Emulator، واضغط Run.
4. في التطبيق: الإعدادات → حط المفتاح.
5. الرئيسية → «تفعيل النافذة العائمة»: وافق على (الظهور فوق التطبيقات) → المايك والإشعارات → تسجيل الشاشة (اختار «الشاشة بالكامل»).
6. افتح أي تطبيق → اضغط «ترجم» → اسحب مستطيل على النص.

## هيكل الملفات
- app/build.gradle.kts, build.gradle.kts, settings.gradle.kts : إعدادات البناء
- AndroidManifest.xml : الأذونات والـ Service
- OverlayService.kt : الزرار العائم + التحديد + لقطة الشاشة + كارت الترجمة
- Translate.kt : ML Kit OCR (إنجليزي + عربي أوفلاين) + Gemini + Repository
- Speech.kt : TTS + تقييم النطق
- PracticeActivity.kt : وضع «علّمني»
- Data.kt : Room (السجل + الكلمات المتقنة)
- AppPrefs.kt : إعدادات مشفّرة (مفتاح الـ API)
- MainActivity.kt / Ui.kt : الشاشات الأربعة

---
## تحديثات النسخة 2 (مُصلحة)
- **OCR عربي أوفلاين** بإضافة `text-recognition-arabic`: التطبيق بيقرأ العربي والإنجليزي على جهازك من غير نت. لو مفيش نص واضح خالص بيبعت الصورة لـ Gemini.
- **أيقونة رسمية للتطبيق** (لانشر أيقونة زرقا فيها A وشكل عربي).
